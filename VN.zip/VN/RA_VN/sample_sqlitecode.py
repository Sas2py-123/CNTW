
# =============================================================================
import numpy as np
import pandas as pd
import sqlite3 as db

# =============================================================================
# Get Previous Working Day
# =============================================================================
datadate = datetime(2024,2,18)
str_ods = datadate.strftime('%Y-%m-%d')
log_file.write('ods: ' + str_ods)
log_file.write('\n')
print(str_ods)

str_l1m = '202401'

year_part = datadate.strftime('%Y').strip()
if int(datadate.month)<=3:
    year_part = year_part + '_q1'
elif int(datadate.month)<=6:
    year_part = year_part + '_q2'
elif int(datadate.month)<=6:
    year_part = year_part + '_q3'
else:
    year_part = year_part + '_q4'
print(year_part)

# =============================================================================
#   APPEND MASTER
# =============================================================================

conn = db.connect(rpt_path + r'\datasets\el_customer_' + year_part + '.db')

strQuery='select distinct ods from el_customer_' + year_part 
master = pd.read_sql(strQuery,conn)
master = master.sort_values(by=['ods'], ascending=False, na_position='first')
print(master.to_string())
    
strQuery='delete from el_customer_' + year_part + ' where substr(ods,1,4)||substr(ods,6,2)||substr(ods,9,2)>=\'{ods}\''.format(ods=str_ods.replace('-',''))
cur = conn.cursor()
cur.execute(strQuery)
conn.commit()
    
# INSERT NEW RECORDS
df.to_sql('el_customer_' + year_part, con=conn, if_exists='append')

strQuery='select distinct ods from el_customer_' + year_part + ' order by ods'
master = pd.read_sql(strQuery,conn)
print(master.to_string())

# MANUAL REMOVE HC'LOANS
strQuery="delete from el_customer_" + year_part + " where loan_lm in ('4400519631','4400528338','4400526172','4400536607')"
cur = conn.cursor()
cur.execute(strQuery)
conn.commit()

conn.close()
conn = None

#CREATE CURRENT MONTH DATA
conn = db.connect(rpt_path + r'\datasets\current_loans.db')
curr_loans.to_sql('current_loans', con=conn, if_exists='replace')

# GET FINAL REPORT
strQuery="select month " \
		 ",count(loan_lm) as disb" \
		 ",sum(ntb) as ntb" \
		 ",sum((case when cnt_term<12 then 1 else 0 end)) as tenor_lt12" \
		 ",sum((case when cnt_term>=12 then 1 else 0 end)) as tenor_ge12" \
		 ",sum(adv_amt_lm) as disb_amt_vnd" \
		 ",sum(appr_amt_lm) as approved_amt_vnd" \
		 ",max(enr) as os_prin_bal_amt_vnd" \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then adv_amt_lm else 0 end)) as non_reimbmt_disb_amt_vnd" \
		 ",max(clients_cnt) as clients" \
		 ",max(active_loans) as active_loans" \
		 ",max(active_client_cnt) as active_clients " \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then 1 else 0 end)) as non_reimbmt " \
		 "from current_loans " \
		 "where month={month} " \
		 "group by month".format(month=(str_ods.replace('-','')[0:6]))
monthly_sum = pd.read_sql(strQuery,conn)

#APPEND SUMMARY INFO TO MONTHLY REPORT
conn1 = db.connect(rpt_path + r'\datasets\monthly_rpt.db')
strQuery="delete from monthly_rpt where month={month}".format(month=(str_ods.replace('-','')[0:6]))
cur = conn1.cursor()
cur.execute(strQuery)
conn1.commit()
monthly_sum.to_sql('monthly_rpt', con=conn1, if_exists='append')

# UPDATE LAST MONTH NUMBER
strQuery="select month " \
		 ",count(loan_lm) as disb" \
		 ",sum(ntb) as ntb" \
		 ",sum((case when cnt_term<12 then 1 else 0 end)) as tenor_lt12" \
		 ",sum((case when cnt_term>=12 then 1 else 0 end)) as tenor_ge12" \
		 ",sum(adv_amt_lm) as disb_amt_vnd" \
		 ",sum(appr_amt_lm) as approved_amt_vnd" \
		 ",max(enr) as os_prin_bal_amt_vnd" \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then adv_amt_lm else 0 end)) as non_reimbmt_disb_amt_vnd" \
		 ",max(clients_cnt) as clients" \
		 ",max(active_loans) as active_loans" \
		 ",max(active_client_cnt) as active_clients " \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then 1 else 0 end)) as non_reimbmt " \
		 "from current_loans " \
		 "where month={month} " \
		 "group by month".format(month=str_l1m)
l1m_sum = pd.read_sql(strQuery,conn)

strQuery="update monthly_rpt " \
		 "set disb={disb}, tenor_lt12={tenor_lt12},tenor_ge12={tenor_ge12}" \
		 ",disb_amt_vnd={disb_amt_vnd},approved_amt_vnd={approved_amt_vnd}" \
		 ",non_reimbmt={non_reimbmt},non_reimbmt_disb_amt_vnd={non_reimbmt_disb_amt_vnd} " \
		 "where month={l1m}".format(disb=l1m_sum.disb[0],tenor_lt12=l1m_sum.tenor_lt12[0]
								   ,tenor_ge12=l1m_sum.tenor_ge12[0]
								   ,disb_amt_vnd=l1m_sum.disb_amt_vnd[0]
								   ,approved_amt_vnd=l1m_sum.approved_amt_vnd[0]
								   ,non_reimbmt=l1m_sum.non_reimbmt[0]
								   ,non_reimbmt_disb_amt_vnd=l1m_sum.non_reimbmt_disb_amt_vnd[0]
								   ,l1m=str_l1m)
print(strQuery)
cur = conn1.cursor()
cur.execute(strQuery)
conn1.commit()

# MONTHLY REPORT 
strQuery="select month as org_month" \
		 ",disb,ntb,tenor_lt12,tenor_ge12" \
		 ",(disb_amt_vnd/{fx}) as disb_amt" \
		 ",(approved_amt_vnd/{fx}) as approved_amt" \
		 ",(os_prin_bal_amt_vnd/{fx}) as os_prin_bal_amt" \
		 ",clients,active_loans,active_clients,non_reimbmt" \
		 ",(non_reimbmt_disb_amt_vnd/{fx}) as non_reimbmt_disb_amt " \
		 "from monthly_rpt".format(fx=fx_rate)
monthly_rpt = pd.read_sql(strQuery,conn1)
monthly_rpt['month']=(pd.to_datetime(monthly_rpt.org_month + '01',format='%Y%m%d')).dt.strftime('%b%y').astype('string')
monthly_rpt = monthly_rpt[['month','disb','ntb','tenor_lt12','tenor_ge12','disb_amt','approved_amt','os_prin_bal_amt','clients','active_loans','active_clients','non_reimbmt','non_reimbmt_disb_amt']]

# DAILY REPORT
strQuery="select month as org_month,disb_date" \
		 ",count(loan_lm) as disb" \
		 ",sum(ntb) as ntb" \
		 ",sum((case when cnt_term<12 then 1 else 0 end)) as tenor_lt12" \
		 ",sum((case when cnt_term>=12 then 1 else 0 end)) as tenor_ge12" \
		 ",sum(adv_amt_lm)/{fx} as disb_amt" \
		 ",sum(appr_amt_lm)/{fx} as approved_amt" \
		 ",max(enr)/{fx} as os_prin_bal_amt" \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then adv_amt_lm else 0 end))/{fx} as non_reimbmt_disb_amt" \
		 ",max(clients_cnt) as clients" \
		 ",max(active_loans) as active_loans" \
		 ",max(active_client_cnt) as active_clients " \
		 ",sum((case when substr(product_code,1,5)='CLXSI' then 1 else 0 end)) as non_reimbmt " \
		 "from current_loans " \
		 "where month={month} " \
		 "group by month,disb_date".format(month=(str_ods.replace('-','')[0:6]),fx=fx_rate)
daily_rpt = pd.read_sql(strQuery,conn)
daily_rpt.disb_date = pd.to_datetime(daily_rpt.disb_date,format='%Y-%m-%d')
daily_rpt['month']=(pd.to_datetime(daily_rpt.org_month + '01',format='%Y%m%d')).dt.strftime('%b%y').astype('string')
# daily_rpt['day']=daily_rpt['disb_date'].dt.strftime('%d-%b-%y').astype('string')
daily_rpt = daily_rpt[['month','disb_date','disb','ntb','tenor_lt12','tenor_ge12','disb_amt','approved_amt','os_prin_bal_amt','clients','active_loans','active_clients','non_reimbmt','non_reimbmt_disb_amt']]

print(daily_rpt.dtypes.to_string())

# EXPORT XLSX
with pd.ExcelWriter(rpt_path + r'\raw_data.xlsx') as writer:
	monthly_rpt.to_excel(writer,sheet_name='raw_month', index=False)
	daily_rpt.to_excel(writer,sheet_name='raw_daily',index=False)

